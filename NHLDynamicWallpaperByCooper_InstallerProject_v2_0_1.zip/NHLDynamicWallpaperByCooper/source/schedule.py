"""One user-owned task: daily 06:00 and at-logon, with daily completion guard in app.py."""
import subprocess
from pathlib import Path

NAME = 'NHLDynamicWallpaperByCooper_Daily'
LEGACY_LOGIN = 'NHLDynamicWallpaperByCooper_Logon'
FLAGS = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def _run(args):
    p = subprocess.run(args, capture_output=True, text=True, errors='replace', creationflags=FLAGS)
    if p.returncode:
        raise RuntimeError('Task Scheduler returned '+str(p.returncode)+'\n'+(p.stderr or p.stdout or 'No details supplied')+'\nCommand: '+subprocess.list2cmdline(args))
    return p.stdout


def install(exe):
    exe = str(Path(exe).resolve())
    command = '"'+exe+'" --update --scheduled'
    # Create task owned by the current user, avoiding an elevated/system logon task.
    _run(['schtasks', '/Create', '/F', '/TN', NAME, '/SC', 'DAILY', '/ST', '06:00', '/TR', command])
    # Add both triggers to the SAME task, without creating a separate ONLOGON task.
    # Escape the user-provided executable path only in schtasks (argument array), not PS.
    ps = (
        "$ErrorActionPreference='Stop'; "
        "$task=Get-ScheduledTask -TaskName '"+NAME+"'; "
        "$daily=New-ScheduledTaskTrigger -Daily -At '06:00'; "
        "$login=New-ScheduledTaskTrigger -AtLogOn -User ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name); "
        "$settings=$task.Settings; $settings.StartWhenAvailable=$true; "
        "Set-ScheduledTask -TaskName '"+NAME+"' -Trigger @($daily,$login) -Settings $settings | Out-Null; "
        "$check=Get-ScheduledTask -TaskName '"+NAME+"'; "
        "if ($check.Triggers.Count -ne 2) { throw 'Expected two triggers on daily task' }; "
        "if (-not $check.Settings.StartWhenAvailable) { throw 'Missed-run recovery not enabled' }"
    )
    try:
        _run(['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps])
    except Exception as e:
        return ('6 AM daily task was created, but Windows rejected the at-logon trigger. '
                'Automatic login catch-up is NOT configured. Please report this error:\n'+str(e))
    # Remove obsolete task only after both triggers have been verified.
    subprocess.run(['schtasks', '/Delete', '/F', '/TN', LEGACY_LOGIN],
                   capture_output=True, text=True, creationflags=FLAGS)
    return None


def remove():
    for name in (NAME, LEGACY_LOGIN):
        subprocess.run(['schtasks', '/Delete', '/F', '/TN', name],
                       capture_output=True, text=True, creationflags=FLAGS)

@echo off
cd /d "%~dp0"
if not exist "build_output\WallpaperEngine.exe" (echo Build the app first with build_windows.bat & pause & exit /b 1)
"build_output\WallpaperEngine.exe" --diagnose-monitor
echo Diagnostic saved under %%LOCALAPPDATA%%\NHLDynamicWallpaperByCooper\packaged_monitor_diagnostic.txt
pause

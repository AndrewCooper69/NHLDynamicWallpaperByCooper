import platform,sys,traceback
print('Python:',sys.version)
print('Architecture:',platform.architecture())
print('Windows:',platform.platform())
try:
    from source.monitor_wallpaper import monitors
    print('Detected monitors:',monitors())
except Exception:
    traceback.print_exc()
input('Press Enter to close...')

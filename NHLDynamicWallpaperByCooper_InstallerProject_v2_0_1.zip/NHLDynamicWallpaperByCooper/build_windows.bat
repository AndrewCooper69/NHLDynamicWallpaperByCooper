@echo off
setlocal
cd /d "%~dp0"
set "RELEASE=release\NHLDynamicWallpaperByCooper"
set "TOOLS=%RELEASE%\Uninstaller and Wallpaper Engine"
set "APP_ICON=%CD%\WallpaperByCooperIcon.ico"
if exist "%RELEASE%" rmdir /s /q "%RELEASE%"
mkdir "%TOOLS%"
py -3 -m pip install --upgrade pyinstaller pillow comtypes
if errorlevel 1 goto fail
rem Download and validate every logo before building; fail rather than ship incomplete assets.
py -3 download_team_logos.py
if errorlevel 1 goto fail
py -3 -m PyInstaller --noconfirm --clean --collect-all comtypes --onefile --windowed --icon "%APP_ICON%" --name WallpaperEngine --paths source --add-data "assets\team_logos;team_logos" --distpath "%TOOLS%" source\app.py
if errorlevel 1 goto fail
py -3 -m PyInstaller --noconfirm --clean --collect-all comtypes --onefile --windowed --icon "%APP_ICON%" --name Uninstall_NHLDynamicWallpaperByCooper --paths source --distpath "%TOOLS%" source\uninstall.py
if errorlevel 1 goto fail
py -3 -m PyInstaller --noconfirm --clean --collect-all comtypes --onefile --windowed --icon "%APP_ICON%" --name "NHL Wallpaper Setup and Change Settings" --paths source --add-binary "%TOOLS%\WallpaperEngine.exe;." --add-binary "%TOOLS%\Uninstall_NHLDynamicWallpaperByCooper.exe;." --distpath "%RELEASE%" source\installer.py
if errorlevel 1 goto fail
rem Create a real Windows shortcut that can be moved to the desktop.
rem Its target is the EXE's absolute path inside the distributed folder.
set "SHORTCUT_DIR=%CD%\%RELEASE%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=$env:SHORTCUT_DIR; $exe=Join-Path $d 'NHL Wallpaper Setup and Change Settings.exe'; $lnk=Join-Path $d 'NHL Wallpaper Setup and Change Settings - Desktop Shortcut.lnk'; $w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut($lnk); $s.TargetPath=$exe; $s.WorkingDirectory=$d; $s.IconLocation=$exe+',0'; $s.Save()"
if errorlevel 1 goto fail
copy /y "DISTRIBUTION_README.txt" "%RELEASE%\README - Install and Desktop Shortcut.txt" >nul
if errorlevel 1 goto fail
echo.
echo READY TO ZIP: %RELEASE%
echo Send the whole NHLDynamicWallpaperByCooper folder to your friends.
echo Keep the extracted folder in its final location BEFORE moving the shortcut.
echo.
pause
exit /b 0
:fail
echo Build failed. See messages above.
pause
exit /b 1

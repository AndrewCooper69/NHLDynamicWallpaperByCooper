TEAMS = [
('ANA','Anaheim Ducks','Anaheim','#F47A38','#B9975B'),('BOS','Boston Bruins','Boston','#FFB81C','#000000'),('BUF','Buffalo Sabres','Buffalo','#003087','#FFB81C'),('CGY','Calgary Flames','Calgary','#C8102E','#F1BE48'),('CAR','Carolina Hurricanes','Raleigh','#CC0000','#000000'),('CHI','Chicago Blackhawks','Chicago','#CF0A2C','#000000'),('COL','Colorado Avalanche','Denver','#6F263D','#236192'),('CBJ','Columbus Blue Jackets','Columbus','#002654','#CE1126'),('DAL','Dallas Stars','Dallas','#006847','#8F8F8C'),('DET','Detroit Red Wings','Detroit','#CE1126','#FFFFFF'),('EDM','Edmonton Oilers','Edmonton','#041E42','#FF4C00'),('FLA','Florida Panthers','Sunrise','#C8102E','#041E42'),('LAK','Los Angeles Kings','Los Angeles','#111111','#A2AAAD'),('MIN','Minnesota Wild','Saint Paul','#154734','#A6192E'),('MTL','Montreal Canadiens','Montréal','#AF1E2D','#192168'),('NSH','Nashville Predators','Nashville','#FFB81C','#041E42'),('NJD','New Jersey Devils','Newark','#CE1126','#000000'),('NYI','New York Islanders','New York','#00539B','#F47D30'),('NYR','New York Rangers','New York','#0038A8','#CE1126'),('OTT','Ottawa Senators','Ottawa','#C52032','#C2912C'),('PHI','Philadelphia Flyers','Philadelphia','#F74902','#000000'),('PIT','Pittsburgh Penguins','Pittsburgh','#FCB514','#000000'),('SJS','San Jose Sharks','San Jose','#006D75','#EA7200'),('SEA','Seattle Kraken','Seattle','#001628','#99D9D9'),('STL','St. Louis Blues','St. Louis','#002F87','#FCB514'),('TBL','Tampa Bay Lightning','Tampa','#002868','#FFFFFF'),('TOR','Toronto Maple Leafs','Toronto','#00205B','#FFFFFF'),('UTA','Utah Mammoth','Salt Lake City','#71AFE5','#000000'),('VAN','Vancouver Canucks','Vancouver','#00205B','#00843D'),('VGK','Vegas Golden Knights','Las Vegas','#B4975A','#333F42'),('WSH','Washington Capitals','Washington, D.C.','#041E42','#C8102E'),('WPG','Winnipeg Jets','Winnipeg','#041E42','#7B303E')]
BY_ABBR={t[0]:t for t in TEAMS}
CITIES=sorted(set(t[2] for t in TEAMS))
# Use darkened colours for backgrounds; no bright red/green/orange/white panels.
def rgb(h): return tuple(int(h[i:i+2],16) for i in (1,3,5))
def dark(h, strength=.27):
    r,g,b=rgb(h)
    return (max(8,int(r*strength)),max(17,int(g*strength)),max(30,int(b*strength)))
def theme(abbr):
    if abbr == 'TOR':
        # Original LeafsWallpaper V4.1 palette: #07172e backdrop, #113760 game panels, #092243 alternate.
        return {'base':(7,23,46),'panel':(17,55,96),'alternate':(9,34,67),'accent':(92,170,255)}
    t=BY_ABBR[abbr]; a=dark(t[3],.28); b=dark(t[4],.22)
    return {'base':tuple(max(6,min(36,(x+y)//2)) for x,y in zip(a,b)),'panel':tuple(min(86,x+18) for x in a),'alternate':tuple(min(95,x+24) for x in b),'accent':tuple(max(110,min(220,int(x*.45+105))) for x in rgb(t[3]))}

"""Windows per-monitor wallpaper via Microsoft's IDesktopWallpaper COM interface."""
import json
import ctypes
from pathlib import Path
import comtypes
from comtypes import GUID, HRESULT, IUnknown, COMMETHOD
from ctypes import POINTER, c_uint, c_wchar_p

class RECT(ctypes.Structure):
    _fields_ = [('left', ctypes.c_long), ('top', ctypes.c_long), ('right', ctypes.c_long), ('bottom', ctypes.c_long)]

class IDesktopWallpaper(IUnknown):
    _iid_ = GUID('{B92B56A9-8B55-4E14-9A89-0199BBB6F93B}')
    _methods_ = [
        COMMETHOD([], HRESULT, 'SetWallpaper', (['in'], c_wchar_p, 'monitorID'), (['in'], c_wchar_p, 'wallpaper')),
        COMMETHOD([], HRESULT, 'GetWallpaper', (['in'], c_wchar_p, 'monitorID'), (['out'], POINTER(c_wchar_p), 'wallpaper')),
        COMMETHOD([], HRESULT, 'GetMonitorDevicePathAt', (['in'], c_uint, 'index'), (['out'], POINTER(c_wchar_p), 'monitorID')),
        COMMETHOD([], HRESULT, 'GetMonitorDevicePathCount', (['out'], POINTER(c_uint), 'count')),
        COMMETHOD([], HRESULT, 'GetMonitorRECT', (['in'], c_wchar_p, 'monitorID'), (['out'], POINTER(RECT), 'displayRect')),
    ]

def desktop():
    return comtypes.CoCreateInstance(GUID('{C2CF3110-460E-4FC1-B9D0-8A1C0C9CC4BD}'), interface=IDesktopWallpaper)

def monitors():
    obj = desktop()
    result = []
    for i in range(obj.GetMonitorDevicePathCount()):
        mid = obj.GetMonitorDevicePathAt(i)
        r = obj.GetMonitorRECT(mid)
        result.append({'id':mid, 'index':i, 'width':r.right-r.left, 'height':r.bottom-r.top, 'position':[r.left,r.top]})
    return result

def configure(config_path):
    found = monitors()
    print('Windows monitor IDs (position is only informational):')
    for m in found:
        print(f"  {m['index']}: {m['width']}x{m['height']} at {m['position']}; ID={m['id']}")
    print('Choose the index of your VERTICAL monitor. Nothing changes until you choose.')
    choice = input('Vertical monitor index: ').strip()
    selected = next((m for m in found if str(m['index']) == choice), None)
    if selected is None or selected['height'] <= selected['width']:
        raise ValueError('Selection was invalid or not portrait; no settings changed.')
    config_path.write_text(json.dumps({'monitor_id': selected['id']}, indent=2), encoding='utf-8')
    print('Saved monitor selection. Other monitors will not be changed.')

def set_one(path, config_path):
    if not config_path.exists():
        raise RuntimeError('First run Configure_Vertical_Monitor.bat to choose the correct display.')
    monitor_id = json.loads(config_path.read_text(encoding='utf-8'))['monitor_id']
    current = {m['id']:m for m in monitors()}
    if monitor_id not in current:
        raise RuntimeError('Selected monitor not connected. Re-run monitor configuration; no wallpaper changed.')
    if current[monitor_id]['height'] <= current[monitor_id]['width']:
        raise RuntimeError('Selected monitor is not portrait; refusing to change wallpaper.')
    desktop().SetWallpaper(monitor_id, str(Path(path).resolve()))

import argparse,json,os,sys,traceback
from datetime import datetime
from pathlib import Path
from teams import BY_ABBR,CITIES,TEAMS
from nhl_data import fetch
from render import standings,calendar_image
APP='NHLDynamicWallpaperByCooper'
DATA=Path(os.environ.get('LOCALAPPDATA',Path.home()))/APP
CONFIG=DATA/'config.json'

def read_config():
    if not CONFIG.exists():raise RuntimeError('Configuration missing. Run the installer or Settings.')
    return json.loads(CONFIG.read_text(encoding='utf-8'))

def update(scheduled=False):
    from monitor_wallpaper import monitors,desktop
    cfg=read_config();DATA.mkdir(parents=True,exist_ok=True)
    selected=cfg.get('monitors',{});active={m['id']:m for m in monitors()}
    if not any(v in active for v in selected.values() if v):raise RuntimeError('No configured monitor is currently connected')
    now=datetime.now().astimezone();month=now.strftime('%Y-%m');team=cfg['team'];city=cfg['city']
    if scheduled:
        if now.hour < 6:
            print('Before 6 AM; scheduled run deferred.');return
        stamp=DATA/'last_update.json'
        if stamp.exists():
            try:
                previous=datetime.fromisoformat(json.loads(stamp.read_text(encoding='utf-8'))['time'])
                if previous.date()==now.date() and previous.hour >= 6:
                    print('Already updated today after 6 AM.');return
            except (ValueError,KeyError):pass
    standings_data,standings_stale=fetch('standings/now',DATA/'cache'/'standings.json')
    standings_data=standings_data['standings']
    games_data,games_stale=fetch(f'club-schedule/{team}/month/{month}',DATA/'cache'/f'{team}_{month}.json')
    games=games_data.get('games',[])
    for kind in ('calendar','standings'):
        mid=selected.get(kind)
        if not mid:continue
        if mid not in active:print('Skipping disconnected',kind);continue
        m=active[mid];size=(m['width'],m['height'])
        image=calendar_image(games,standings_data,size,team,city,now) if kind=='calendar' else standings(standings_data,size,team,now,cfg.get("standings_organization","Conference"))
        path=DATA/f'{kind}_{m["width"]}x{m["height"]}.png';image.save(path,optimize=True)
        desktop().SetWallpaper(mid,str(path.resolve()));print('Updated',kind,size)
    if standings_stale or games_stale:print('WARNING: Offline cached NHL data was used.')
    (DATA/'last_update.json').write_text(json.dumps({'time':now.isoformat(),'cached':standings_stale or games_stale}),encoding='utf-8')

def settings():
    import tkinter as tk
    from tkinter import ttk,messagebox
    from monitor_wallpaper import monitors
    cfg=read_config();win=tk.Tk();win.title(APP+' - Settings');win.geometry('650x570');win.resizable(False,False)
    try:
        ms=monitors();monitor_error=None
    except Exception as e:
        ms=[];monitor_error=str(e)
    f=ttk.Frame(win,padding=22);f.pack(fill='both',expand=True)
    if monitor_error:
        ttk.Label(f,text='Windows monitor detection failed: '+monitor_error+'\nExisting monitor selections will be retained until this is fixed.',wraplength=600,foreground='red').grid(row=0,column=0,sticky='w')
    team_var=tk.StringVar(value=BY_ABBR[cfg['team']][1]);city_var=tk.StringVar(value=cfg['city']);organization_var=tk.StringVar(value=cfg.get('standings_organization','Conference'))
    values={f"{m['index']}: {m['width']}x{m['height']} at {m['position']}":m['id'] for m in ms};values={'Disabled':None,**values}
    if monitor_error:
        for kind in ('calendar','standings'):
            mid=cfg.get('monitors',{}).get(kind)
            if mid:values['Previously selected '+kind]=mid
    def display(mid):return next((k for k,v in values.items() if v==mid),'Disabled')
    c_var=tk.StringVar(value=display(cfg['monitors'].get('calendar')));s_var=tk.StringVar(value=display(cfg['monitors'].get('standings')))
    for i,(label,var,choices) in enumerate((('Favourite NHL team',team_var,[t[1] for t in TEAMS]),('Viewing city',city_var,CITIES),('Calendar monitor',c_var,list(values)),('Standings monitor',s_var,list(values)),('Standings organization',organization_var,['Division','Conference','League']))):
        ttk.Label(f,text=label).grid(row=i*2,column=0,sticky='w',pady=(8,2));ttk.Combobox(f,textvariable=var,values=choices,state='readonly',width=63).grid(row=i*2+1,column=0,sticky='ew')
    def save():
        if monitor_error:
            messagebox.showerror('Monitor unavailable','Cannot safely update monitor assignments until detection works.');return
        a=values[c_var.get()];b=values[s_var.get()]
        if a and a==b:messagebox.showerror('Monitor conflict','Choose two different monitors.');return
        if not a and not b:messagebox.showerror('No monitor','Enable at least one wallpaper.');return
        cfg.update(team=next(t[0] for t in TEAMS if t[1]==team_var.get()),city=city_var.get(),monitors={'calendar':a,'standings':b},standings_organization=organization_var.get())
        CONFIG.write_text(json.dumps(cfg,indent=2),encoding='utf-8')
        try:update();messagebox.showinfo('Saved','Settings saved and wallpapers updated.')
        except Exception as e:messagebox.showwarning('Saved','Settings saved, but update failed: '+str(e))
    ttk.Button(f,text='Save and update wallpapers',command=save).grid(row=11,column=0,pady=22)
    win.mainloop()

def main():
    p=argparse.ArgumentParser();p.add_argument('--settings',action='store_true');p.add_argument('--update',action='store_true');p.add_argument('--scheduled',action='store_true');p.add_argument('--diagnose-monitor',action='store_true');args=p.parse_args()
    if args.diagnose_monitor:
        import traceback
        from tkinter import messagebox
        try:
            from monitor_wallpaper import monitors
            detected = monitors()
            report = 'Packaged executable monitor test SUCCESS\n' + '\n'.join(f"{m['index']}: {m['width']}x{m['height']}" for m in detected)
        except Exception:
            report = 'Packaged executable monitor test FAILED\n' + traceback.format_exc()
        DATA.mkdir(parents=True, exist_ok=True)
        (DATA/'packaged_monitor_diagnostic.txt').write_text(report, encoding='utf-8')
        messagebox.showinfo('Packaged monitor diagnostic',report[:3000])
        return
    try:
        if args.settings or not args.update:settings()
        else:update(scheduled=args.scheduled)
    except Exception:
        DATA.mkdir(parents=True,exist_ok=True)
        with (DATA/'error.log').open('a',encoding='utf-8') as f:f.write(datetime.now().isoformat()+'\n'+traceback.format_exc()+'\n')
        raise
if __name__=='__main__':main()

# NHLDynamicWallpaperByCooper — Windows installer source (preview build)

This project combines the previously working LeafsWallpaper V4.1 monitor interface and NHLStandingsWallpaper V1.5 design into one configurable application. It supports one or two monitors, either portrait or landscape, any NHL team, and a separate NHL-market viewing city. It uses NHL public API data with local caching.

## Produce the single-file installer on Windows 11

1. Install Python 3.11 or newer from python.org, ensuring the `py` launcher is available.
2. Extract this project and run **`build_windows.bat`**. It installs build dependencies and builds three executables internally, then packages them into **one distributable installer**.
3. Distribute **only** `build_output\NHLDynamicWallpaperByCooper_Setup.exe`. Recipients do not need Python or a separate dependency installation.
4. Launch the installer. Choose folder, team, viewing city, and monitor assignments. The installed app opens Settings when double-clicked; the shared task updates both wallpapers daily.
5. To uninstall, run `Uninstall_NHLDynamicWallpaperByCooper.exe` in the chosen application directory.

## Limitations / important notes

- **This is source code for a Windows installer, not a compiled EXE.** It has passed Python compilation and portrait/landscape sample image generation, but the installer, Windows COM display handling, scheduling and migration must be tested on Windows.
- Installer detects existing unified installations and preserves settings. It also searches common older LeafsWallpaper and NHLStandingsWallpaper folders for monitor selections; **older application files and scheduled tasks are not automatically removed** to avoid breaking working setups. Disable old tasks manually after confirming the unified installation. The new uninstaller only removes its own task and files.
- NHL `tvBroadcasts` is filtered by Canada/US, based on the selected NHL city. This is **not authoritative city-specific carriage or blackout information**; network availability is labelled as unverified on the calendar. An external verified market-level guide would be required to guarantee that a Buffalo viewer can watch a particular Leafs game.
- Monitor IDs are saved; if Windows changes IDs after a display or GPU reconfiguration, run Settings again.
- The installer defaults to a per-user folder under `%LOCALAPPDATA%` to avoid administrator requirements. Choosing a protected folder may require elevation.
- Uninstall removes the generated wallpaper files, but Windows may still display a cached copy of the last wallpaper until the user chooses another wallpaper.
- The scheduler uses a single 6 AM daily task with Task Scheduler `StartWhenAvailable` enabled (no separate logon task). It runs no earlier than 6 AM, at most once per local calendar day. Windows may delay missed-run recovery after login.
- Broadcast listings, standings, and game times depend on NHL API responses and may change. When offline, the program may use cached data and records this in `last_update.json`.

## Source layout

- `source/installer.py` — graphical installer and legacy monitor-selection migration
- `source/app.py` — wallpaper updates and settings GUI
- `source/render.py` — adaptive calendar and standings renderers
- `source/nhl_data.py` — NHL API and broadcaster listings
- `source/monitor_wallpaper.py` — tested per-monitor COM interface
- `source/schedule.py` — one shared Windows task
- `source/uninstall.py` — uninstall GUI
- `source/teams.py` — 32 teams, colours and city list


## V1.5 scheduler and Toronto colours

The single task `NHLDynamicWallpaperByCooper_Daily` now requests two triggers: daily 6:00 AM and at logon of the current user. The scheduled updater skips before 6 AM and skips duplicate updates on the same date. Verify **both** triggers in Task Scheduler after upgrading. If Windows rejects the logon trigger, the installer shows the error rather than claiming success. Toronto restores the original V4.1 dark navy and blue background palette.

V1.9: The installer/settings UI is NHLDynamicWallpaperByCooper_Setup.exe. The background renderer is WallpaperEngine.exe (required for scheduled updates). Uninstall_NHLDynamicWallpaperByCooper.exe removes the installation. Landscape standings show conferences side by side.

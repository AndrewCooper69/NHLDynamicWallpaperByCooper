import json, urllib.request
from pathlib import Path
from datetime import datetime

def fetch(endpoint, cache):
    cache=Path(cache); cache.parent.mkdir(parents=True,exist_ok=True)
    try:
        req=urllib.request.Request('https://api-web.nhle.com/v1/'+endpoint,headers={'User-Agent':'NHLDynamicWallpaperByCooper/1.0'})
        with urllib.request.urlopen(req,timeout=25) as resp: data=json.load(resp)
        cache.write_text(json.dumps(data),encoding='utf-8')
        return data,False
    except Exception:
        if cache.exists(): return json.loads(cache.read_text(encoding='utf-8')),True
        raise

def label(x): return x.get('default','') if isinstance(x,dict) else str(x or '')

def broadcasts(game, city):
    # NHL API broadcast listings provide country, but not definitive city-by-city carriage.
    # Show only network names actually returned by the NHL, explicitly not a guarantee.
    country='CA' if city in {'Toronto','Montréal','Ottawa','Winnipeg','Calgary','Edmonton','Vancouver'} else 'US'
    networks=[]
    for item in game.get('tvBroadcasts') or []:
        if str(item.get('countryCode','')).upper()==country:
            name=str(item.get('network','')).strip()
            if name and name not in networks: networks.append(name)
    return ' / '.join(networks[:2]) if networks else 'Broadcast TBC'

@echo off
cd /d "%~dp0"
py -3 -m pip install comtypes
py -3 diagnose_monitor.py
pause

"""Transparent PNG logo cache. ESPN NHL transparent marks; fallback has alpha."""
import os,io,time,sys
from pathlib import Path
from urllib.request import Request,urlopen
from PIL import Image,ImageDraw,ImageFont
from teams import BY_ABBR
CACHE=Path(os.environ.get('LOCALAPPDATA',Path.home()))/'NHLDynamicWallpaperByCooper'/'logos'
BUNDLED=Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))/'team_logos'

def logo(abbr):
    if abbr not in BY_ABBR:return None
    packaged=BUNDLED/(abbr+'.png')
    if packaged.is_file():
        try:
            return Image.open(packaged).convert('RGBA')
        except (OSError, ValueError):
            pass
    path=CACHE/(abbr+'.png')
    if path.exists():
        try:return Image.open(path).convert('RGBA')
        except OSError:pass
    # Avoid repeated network delays if an offline update cannot retrieve logos.
    miss=CACHE/(abbr+'.retry')
    if miss.exists() and time.time()-miss.stat().st_mtime<3600:return None
    try:
        url=f'https://a.espncdn.com/i/teamlogos/nhl/500/{abbr.lower()}.png'
        with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=4) as response:
            raw=response.read(3_000_000)
        im=Image.open(io.BytesIO(raw)).convert('RGBA')
        if im.width<40 or im.height<40:raise ValueError('Logo too small')
        CACHE.mkdir(parents=True,exist_ok=True);im.save(path)
        if miss.exists():miss.unlink()
        return im
    except Exception:
        CACHE.mkdir(parents=True,exist_ok=True);miss.touch()
        return None

def paste_logo(canvas,abbr,box):
    x,y,w,h=map(int,box)
    if w<1 or h<1:return
    im=logo(abbr)
    if im is None:
        # Transparent-background abbreviation placeholder when offline on first run.
        im=Image.new('RGBA',(200,200),(0,0,0,0));d=ImageDraw.Draw(im)
        for fp in ('C:/Windows/Fonts/arialbd.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'):
            if Path(fp).exists():f=ImageFont.truetype(fp,57);break
        else:f=ImageFont.load_default()
        d.text((100,100),abbr,font=f,fill=(232,242,255,255),anchor='mm')
    im.thumbnail((w,h),Image.Resampling.LANCZOS)
    canvas.paste(im,(x+(w-im.width)//2,y+(h-im.height)//2),im)

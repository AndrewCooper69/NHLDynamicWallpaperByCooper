"""Fetch and validate all 32 transparent NHL logo PNGs before building.

This runs on the developer's Windows computer; the finished executable has no
network dependency for logos. No logos are redistributed in the source ZIP.
"""
import io
import json
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from PIL import Image

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))
from teams import TEAMS

OUT = ROOT / 'assets' / 'team_logos'
API = 'https://site.web.api.espn.com/apis/site/v2/sports/hockey/nhl/teams'
ALIASES = {'SJS': 'sj', 'LAK': 'la', 'TBL': 'tb', 'NJD': 'nj', 'NYR': 'nyr', 'NYI': 'nyi', 'UTA': 'utah', 'MTL': 'mtl'}

def get(url):
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0 (compatible; NHLWallpaperByCooper/2.0.1)', 'Accept': 'image/png,image/*,application/json'})
    with urlopen(req, timeout=18) as resp:
        return resp.read(6_000_000)

def team_entries(obj):
    # ESPN team-list responses wrap teams under sports/leagues/teams.
    if isinstance(obj, dict):
        if 'team' in obj and isinstance(obj['team'], dict):
            yield obj['team']
        if 'id' in obj and 'logos' in obj:
            yield obj
        for value in obj.values():
            yield from team_entries(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from team_entries(value)

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    catalog = {}
    try:
        for t in team_entries(json.loads(get(API))):
            keys = [t.get('abbreviation', ''), t.get('shortDisplayName', ''), t.get('displayName', '')]
            for key in keys:
                if key:
                    catalog[key.lower()] = t
        print('ESPN team catalog retrieved.')
    except Exception as exc:
        print('Team catalog unavailable; trying logo CDN aliases:', exc)
    failures = []
    for abbr, full, *_ in TEAMS:
        dest = OUT / f'{abbr}.png'
        if dest.exists():
            try:
                im = Image.open(dest)
                im.load()
                if im.width >= 80 and im.height >= 80 and im.getchannel('A').getextrema()[0] < 255:
                    print('OK (existing):', abbr)
                    continue
            except Exception:
                pass
        entry = catalog.get(abbr.lower()) or catalog.get(full.lower()) or catalog.get(ALIASES.get(abbr, '').lower())
        urls = []
        if entry:
            for mark in entry.get('logos', []):
                href = mark.get('href', '')
                if href:
                    urls.append(href)
        for alias in dict.fromkeys([ALIASES.get(abbr, abbr.lower()), abbr.lower()]):
            urls.append(f'https://a.espncdn.com/i/teamlogos/nhl/500/{alias}.png')
        error = ''
        for url in urls:
            try:
                im = Image.open(io.BytesIO(get(url))).convert('RGBA')
                im.load()
                if min(im.size) < 80:
                    raise ValueError('Image dimensions too small')
                if im.getchannel('A').getextrema()[0] == 255:
                    raise ValueError('Logo has no transparent pixels')
                im.thumbnail((512, 512), Image.Resampling.LANCZOS)
                im.save(dest, format='PNG', optimize=True)
                print('OK:', abbr, im.size)
                break
            except Exception as exc:
                error = str(exc)
        else:
            failures.append(abbr)
            print('FAILED:', abbr, error)
    if failures:
        print('\nERROR: Missing team logos:', ', '.join(failures))
        print('Build stopped so you do not accidentally distribute missing logos.')
        return 1
    print('\nAll 32 transparent logos verified. Ready to bundle into WallpaperEngine.exe.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

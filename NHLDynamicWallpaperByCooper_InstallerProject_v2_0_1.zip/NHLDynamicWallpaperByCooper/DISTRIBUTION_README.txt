NHL Dynamic Wallpaper by Cooper - Installation

1. Extract the entire NHLDynamicWallpaperByCooper folder from the ZIP.
2. Keep the extracted folder somewhere permanent (e.g. Documents or Applications).
3. Double-click "NHL Wallpaper Setup and Change Settings.exe" to install and choose your settings.
4. OPTIONAL: Move (not the EXE, only) "NHL Wallpaper Setup and Change Settings - Desktop Shortcut.lnk" onto your desktop.
   The shortcut points to the installer in its ORIGINAL extracted location.
   If you move or rename the extracted folder later, recreate the shortcut.

The "Uninstaller and Wallpaper Engine" folder contains support EXEs.
The Setup EXE bundles its own copies of them; you do not need to open them manually.
No Python installation is needed for recipients.

NOTE FOR BUILDER: Run build_windows.bat on Windows with Python installed.
Zip the folder inside "release", not the whole source project.

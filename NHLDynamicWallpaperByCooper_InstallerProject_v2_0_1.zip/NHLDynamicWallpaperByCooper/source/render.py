import calendar, math, random
from datetime import datetime, date
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from logos import paste_logo
from teams import BY_ABBR,theme
from nhl_data import label,broadcasts

def font(size,bold=False):
    for p in ([r'C:\Windows\Fonts\arialbd.ttf',r'C:\Windows\Fonts\segoeuib.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'] if bold else [r'C:\Windows\Fonts\arial.ttf',r'C:\Windows\Fonts\segoeui.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']):
        if Path(p).exists():return ImageFont.truetype(p,max(8,int(size)))
    return ImageFont.load_default()
WHITE=(245,249,255);PALE=(194,216,237);GREEN=(106,229,147);RED=(255,118,118);ORANGE=(255,176,79)
def fit(d,s,maxw,sz,bold=False):
    while sz>9 and d.textbbox((0,0),s,font=font(sz,bold))[2]>maxw:sz-=1
    return font(sz,bold)
def backdrop(size,t):
    w,h=size; colors=theme(t);im=Image.new('RGB',size,colors['base']);d=ImageDraw.Draw(im)
    if t != 'TOR':
        for y in range(h):
            frac=y/max(1,h); c=colors['base']; d.line((0,y,w,y),fill=tuple(min(65,int(v+frac*14)) for v in c))
    # Deterministic, subtle rink-ice/grain texture across both wallpaper types.
    grain=Image.new('RGBA',size,(0,0,0,0));g=ImageDraw.Draw(grain,'RGBA')
    rng=random.Random(1909)
    for _ in range(max(250,(w*h)//1800)):
        x=rng.randrange(w);y=rng.randrange(h)
        g.point((x,y),fill=(165,199,239,rng.randrange(7,25)))
    for _ in range(max(24,h//16)):
        y=rng.randrange(h);x=rng.randrange(w)
        g.line((x,y,min(w-1,x+rng.randrange(12,110)),y),fill=(120,178,229,11),width=1)
    im=Image.alpha_composite(im.convert('RGBA'),grain).convert('RGB')
    return im,ImageDraw.Draw(im),colors

def finish_texture(im):
    """Visible ice-like texture overlay applied after all panels and labels are rendered.

    Deliberately uses mid-frequency, restrained highlights that remain visible on
    1080p and 4K desktops. Deterministic so daily updates do not flicker.
    """
    w,h=im.size
    overlay=Image.new('RGBA',(w,h),(0,0,0,0))
    d=ImageDraw.Draw(overlay,'RGBA')
    rng=random.Random(271828)
    # Short frost scratches: distinct enough to see on the navy panels.
    for _ in range(max(450,(w*h)//1700)):
        x=rng.randrange(w); y=rng.randrange(h)
        length=rng.randint(10,80)
        d.line((x,y,min(w-1,x+length),y),fill=(165,209,255,rng.randint(35,75)),width=1)
    # Small ice crystals, not a flat grain that disappears at wallpaper scale.
    for _ in range(max(1200,(w*h)//560)):
        x=rng.randrange(w); y=rng.randrange(h)
        alpha=rng.randint(30,75)
        d.ellipse((x,y,x+1,y+1),fill=(170,211,250,alpha))
    # Broken diagonal ice scoring, spaced widely to avoid interfering with text.
    for offset in range(-h,w,94):
        for y0 in range(0,h,90):
            if rng.random()<.38:
                continue
            x0=offset+y0
            d.line((x0,y0,x0+min(46,h-y0),min(h-1,y0+46)),
                   fill=(118,178,232,30),width=1)
    return Image.alpha_composite(im.convert('RGBA'),overlay).convert('RGB')

def toronto_skyline(im):
    """Scale the original V4.1 CN Tower/skyline artwork to the icon-safe right sidebar."""
    w,h=im.size
    if h>w:
        return im  # The portrait calendar has no reserved right-hand desktop-icon strip.
    # Work in the original 3840x2160 coordinates to preserve the V4.1 proportions.
    sw,sh=3840,2160
    art=Image.new('RGBA',(sw,sh),(0,0,0,0))
    d=ImageDraw.Draw(art,'RGBA');rng=random.Random(34);start=3050
    for _ in range(155):
        x,y=rng.randint(start+20,sw-20),rng.randint(90,1480)
        r=rng.choice([1,1,2,3]);d.ellipse((x-r,y-r,x+r,y+r),fill=(157,202,255,rng.randint(70,190)))
    for x in range(start,sw,70):
        building_h=rng.randint(300,760);y=1900-building_h
        d.rectangle((x,y,x+66,1920),fill=(5,18,38,255))
        for wx in range(x+11,x+65,19):
            for wy in range(y+22,1890,29):
                if rng.random()<.43:d.rectangle((wx,wy,wx+6,wy+11),fill=(255,194,110,rng.randint(100,210)))
    cx=3450
    d.polygon([(cx-36,1880),(cx+36,1880),(cx+15,660),(cx-15,660)],fill=(105,154,210,255))
    d.line((cx,660,cx,135),fill=(170,217,255,255),width=13)
    d.line((cx,135,cx,90),fill=(100,179,255,255),width=7)
    d.ellipse((cx-105,600,cx+105,670),fill=(27,80,143,255),outline=(140,207,255,255),width=9)
    d.rectangle((cx-77,627,cx+77,645),fill=(145,214,255,245))
    d.ellipse((cx-70,580,cx+70,617),fill=(29,93,158,255))
    d.line((cx-11,680,cx-11,1850),fill=(84,160,244,170),width=7)
    d.rectangle((start,1900,sw,sh),fill=(5,23,50,255))
    for _ in range(90):
        y=rng.randint(1910,sh-25);x=rng.randint(start+5,sw-15)
        d.line((x,y,x+rng.randint(15,85),y),fill=(47,115,191,rng.randint(50,160)),width=2)
    if (w,h)!=(sw,sh):art=art.resize((w,h),Image.Resampling.LANCZOS)
    im.paste(art,(0,0),art)
    return im

def game_result(game,team,game_dt):
    """Show completed scores, including OT/SO; never show a start time for a final game."""
    home=game.get('homeTeam') or {};away=game.get('awayTeam') or {}
    is_home=home.get('abbrev')==team
    state=str(game.get('gameState') or '').upper()
    if state in ('FINAL','OFF'):
        hs=home.get('score');aws=away.get('score')
        if hs is not None and aws is not None:
            try:
                own=int(hs if is_home else aws);other=int(aws if is_home else hs)
                outcome=(game.get('gameOutcome') or {}).get('lastPeriodType','')
                suffix=' '+outcome if outcome in ('OT','SO') else ''
                return f"{'W' if own>other else 'L' if own<other else 'T'} {own}-{other}{suffix}"
            except (TypeError,ValueError):pass
        return 'FINAL - score TBC'
    if state in ('LIVE','CRIT'):
        hs=home.get('score');aws=away.get('score')
        if hs is not None and aws is not None:return f'LIVE {hs}-{aws}'
        return 'LIVE'
    return game_dt.strftime('%I:%M %p').lstrip('0') if game_dt else 'Time TBC'

def standings(data,size,team,now,organization="Conference"):
    w,h=size;portrait=h>w;scale=min(w/1080,h/1920) if portrait else min(w/1920,h/1080)
    im,d,c=backdrop(size,team);left=int(w*.076);right=int(w*.924);top=int(h*.104 if portrait else h*.15);bottom=int(h*.964)
    header_top=int(h*.015);header_bottom=top-int(h*.01)
    d.rounded_rectangle((left,header_top,right,header_bottom),radius=15,fill=c['panel'])
    fs=min(int((header_bottom-header_top)*.60),int(w*.085))
    d.text((w/2,(header_top+header_bottom)/2),'NHL STANDINGS',font=fit(d,'NHL STANDINGS',right-left-35,fs,True),fill=WHITE,anchor='mm')
    if organization != "Conference":
        return custom_standings(data,size,team,now,organization,im,d,c,left,right,top,bottom)
    if not portrait:
        return horizontal_standings(data,size,team,now,im,d,c,left,right,top,bottom)
    cols=[('R',.037),('TEAM',.211),('GP',.047),('W',.042),('L',.042),('OT',.045),('PTS',.053),('WIN%',.067),('GF',.046),('GA',.046),('DIFF',.063),('L10',.092),('STRK',.068)]
    total=sum(x for _,x in cols);centers=[];cur=left
    for _,v in cols:
        span=(right-left)*v/total;centers.append((cur+span/2,span));cur+=span
    # Reserve footer; adapt row height to both orientations and resolution.
    available=bottom-top;gap=int(12*scale);section_h=int(38*scale);head_h=int(28*scale);footer_h=int(65*scale)
    row_h=(available-2*(section_h+head_h+gap)-footer_h)//32
    if row_h<13:raise ValueError('Display too small to fit standings legibly')
    y=top
    for conf in ('Eastern','Western'):
        members=sorted([t for t in data if label(t.get('conferenceName')).lower().startswith(conf.lower())],key=lambda t:int(t.get('conferenceSequence') or 99))
        if len(members)!=16:raise ValueError('Standings incomplete: '+conf)
        d.rounded_rectangle((left,y,right,y+section_h),radius=7,fill=c['panel'])
        d.text((left+12,y+section_h/2),conf.upper()+' CONFERENCE',font=font(min(24,int(section_h*.58)),True),fill=WHITE,anchor='lm');y+=section_h
        d.rectangle((left,y,right,y+head_h),fill=c['alternate'])
        for (name,_),(cx,_) in zip(cols,centers):d.text((cx,y+head_h/2),name,font=fit(d,name,(right-left)*.08,min(16,int(head_h*.55)),True),fill=PALE,anchor='mm')
        y+=head_h
        for i,t in enumerate(members):
            selected=label(t.get('teamAbbrev'))==team
            d.rectangle((left,y,right,y+row_h),fill=c['panel'] if selected else (c['base'] if i%2==0 else c['alternate']))
            d.line((left,y+row_h,right,y+row_h),fill=(60,80,106),width=1)
            gp=int(t.get('gamesPlayed') or 0);wins=int(t.get('wins') or 0);wr=wins/gp if gp else None
            diff=int(t.get('goalDifferential') or 0);s=str(t.get('streakCode') or '');sc=t.get('streakCount') or 0
            streak=('OT' if s.upper() in ('OT','O') else s.upper())+str(sc) if s else '—'
            name=label(t.get('teamName')) or label(t.get('teamAbbrev'))
            vals=[str(i+1),name,str(gp),str(wins),str(t.get('losses',0)),str(t.get('otLosses',0)),str(t.get('points',0)),f'{wr:.3f}' if wr is not None else '—',str(t.get('goalFor',0)),str(t.get('goalAgainst',0)),f'{diff:+d}' if diff else '0',f"{t.get('l10Wins',0)}-{t.get('l10Losses',0)}-{t.get('l10OtLosses',0)}",streak]
            for j,(v,(cx,cw)) in enumerate(zip(vals,centers)):
                color=WHITE
                if j==7 and wr is not None:color=GREEN if wr>.5 else RED if wr<.5 else WHITE
                if j==10:color=GREEN if diff>0 else RED if diff<0 else WHITE
                if j==12:color=GREEN if streak.startswith('W') else RED if streak.startswith('L') else ORANGE if streak.startswith('OT') else WHITE
                f=fit(d,v,cw-3,min(int(row_h*.47),22 if not portrait else 17),selected)
                d.text((cx if j!=1 else cx-cw/2+4,y+row_h/2),v,font=f,fill=color,anchor='mm' if j!=1 else 'lm')
            y+=row_h
        y+=gap
    if y+footer_h>bottom:raise ValueError('Footer exceeds safe display area')
    d.text((w/2,y+int(8*scale)),'UPDATED DAILY - NHL OFFICIAL STANDINGS DATA',font=fit(d,'UPDATED DAILY - NHL OFFICIAL STANDINGS DATA',right-left-20,max(12,int(18*scale)),True),fill=PALE,anchor='mt')
    stamp='LAST UPDATED: '+now.strftime('%b %d, %Y - %I:%M %p %Z')
    d.text((w/2,y+int(33*scale)),stamp,font=fit(d,stamp,right-left-20,max(12,int(19*scale))),fill=PALE,anchor='mt')
    return finish_texture(im)

def calendar_image(games,standings_data,size,team,city,now):
    w,h=size;portrait=h>w;im,d,c=backdrop(size,team)
    if team=='TOR':
        toronto_skyline(im)
        d=ImageDraw.Draw(im)
    # Full-width adaptive grid. Landscape reserves rightmost 18% for desktop icons.
    left=int(w*.04);right=int(w*(.96 if portrait else .80));top=int(h*.20);bottom=int(h*.88)
    name=BY_ABBR[team][1].upper();month=now.strftime('%B %Y').upper()
    title_sz=min(int(h*.066),int(w*.08));d.text((left,int(h*.032)),name,font=fit(d,name,(right-left)*.60,title_sz,True),fill=WHITE)
    month_y=int(h*.105)
    month_font=fit(d,month,right-left,int(h*.045),True)
    d.text((left,month_y),month,font=month_font,fill=PALE)
    record=next((t for t in standings_data if label(t.get('teamAbbrev'))==team),None)
    if record:
        line=f"RECORD: {record.get('wins',0)}-{record.get('losses',0)}-{record.get('otLosses',0)} (W-L-OT)"
        # Align the season record with the MONTH baseline, not over the grid.
        month_width=d.textbbox((0,0),month,font=month_font)[2]
        available=max(80,right-left-month_width-24)
        record_font=fit(d,line,available,int(h*.025),True)
        # Compute the rendered glyph centers, not the text anchor/baseline.
        # This works even when the month and record use different font sizes.
        month_box=d.textbbox((0,0),month,font=month_font)
        record_box=d.textbbox((0,0),line,font=record_font)
        month_center=month_y+(month_box[1]+month_box[3])/2
        record_top=round(month_center-(record_box[1]+record_box[3])/2)
        d.text((right-record_box[2],record_top),line,font=record_font,fill=PALE)
    # The header logo occupies the reserved gap between title and record.
    logo_size=min(int(h*.138),int((right-left)*.145))
    logo_x=int(left+(right-left)*.695-logo_size/2)
    paste_logo(im,team,(logo_x,int(h*.036),logo_size,logo_size))
    d=ImageDraw.Draw(im)
    weeks=calendar.Calendar(firstweekday=6).monthdayscalendar(now.year,now.month)
    cw=(right-left)/7;head=int(h*.037);ch=(bottom-top-head)/len(weeks)
    for j,day in enumerate(('SUN','MON','TUE','WED','THU','FRI','SAT')):
        x=left+j*cw;d.rectangle((x,top,x+cw,top+head),fill=c['panel'],outline=(0,0,0),width=2)
        d.text((x+cw/2,top+head/2),day,font=fit(d,day,cw-5,int(head*.50),True),fill=WHITE,anchor='mm')
    indexed={}
    for g in games:
        try:
            if g.get('gameDate','')[:7]!=now.strftime('%Y-%m'):continue
            game_day=int(g['gameDate'][8:10]);indexed.setdefault(game_day,[]).append(g)
        except (KeyError,ValueError):pass
    for row,week in enumerate(weeks):
        for col,day in enumerate(week):
            x=left+col*cw;y=top+head+row*ch;active=day in indexed
            d.rectangle((x,y,x+cw,y+ch),fill=c['panel'] if active else c['base'],outline=(0,0,0),width=2)
            if not day:continue
            if day==now.day:d.rectangle((x+2,y+2,x+cw-2,y+ch-2),outline=c['accent'],width=3)
            d.text((x+5,y+5),str(day),font=font(min(31,int(ch*.17)),True),fill=WHITE)
            for n,g in enumerate(indexed.get(day,[])[:2]):
                home=g.get('homeTeam') or {};away=g.get('awayTeam') or {};is_home=home.get('abbrev')==team
                opp=away if is_home else home;opptxt=('vs ' if is_home else '@ ')+str(opp.get('abbrev','TBD'))
                start=g.get('startTimeUTC');game_dt=None
                if start:
                    try:game_dt=datetime.fromisoformat(start.replace('Z','+00:00')).astimezone()
                    except ValueError:pass
                result=game_result(g,team,game_dt)
                network=broadcasts(g,city)
                # Three clearly separated baselines, matching the original Leafs V4.1 calendar.
                # Text positions use font bounding boxes so large scores never overlap opponents.
                base=y+ch*.26+n*ch*.38
                result_color=PALE
                if result.startswith('W '):result_color=GREEN
                elif result.startswith('L '):result_color=ORANGE if result.endswith((' OT',' SO')) else RED
                # Slightly larger type while reserving space on the right for opponent logo.
                lines=((opptxt,.190,True,WHITE),(result,.157,True,result_color),(network,.117,False,PALE))
                logo_side=int(min(cw*.40,ch*.38))
                # Centre the logo in the right-side space, with breathing room at the cell edge.
                logo_right_padding=int(cw*.115) if not portrait else 7
                logo_left=int(x+cw-logo_side-logo_right_padding)
                paste_logo(im,str(opp.get('abbrev','')),(logo_left,int(base),logo_side,logo_side))
                d=ImageDraw.Draw(im)
                cursor=base
                for txt,frac,is_bold,color in lines:
                    f=fit(d,txt,max(12,logo_left-x-13),min(int(ch*frac),34),is_bold)
                    bbox=d.textbbox((0,0),txt,font=f)
                    height=bbox[3]-bbox[1]
                    d.text((x+6,cursor-bbox[1]),txt,font=f,fill=color)
                    cursor+=height+max(3,int(ch*.027))
    foot=f'VIEWING MARKET: {city.upper()}'
    d.text((left,int(h*.915)),foot,font=fit(d,foot,right-left,int(h*.018)),fill=PALE)
    return finish_texture(im)


def horizontal_standings(data,size,team,now,im,d,c,left,right,top,bottom):
    """Landscape: East and West side by side, respecting 7.6%-92.4% safe width."""
    w,h=size
    gap=max(10,int(w*.016));pane_w=(right-left-gap)/2
    # Compact headings allow readable 16-row conference columns.
    cols=[('R',.035),('TEAM',.196),('GP',.050),('W',.045),('L',.045),('OT',.048),('PTS',.059),('WIN%',.078),('GF',.048),('GA',.048),('DIFF',.067),('L10',.103),('STRK',.078)]
    total=sum(v for _,v in cols)
    section_h=max(26,int(h*.046));head_h=max(24,int(h*.036))
    footer_h=max(44,int(h*.07));row_h=int((bottom-top-section_h-head_h-footer_h)/16)
    if row_h<17:raise ValueError('Screen too short to display two readable standings tables')
    for ci,conf in enumerate(('Eastern','Western')):
        x0=left+ci*(pane_w+gap);x1=x0+pane_w
        members=sorted([t for t in data if label(t.get('conferenceName')).lower().startswith(conf.lower())],key=lambda t:int(t.get('conferenceSequence') or 99))
        if len(members)!=16:raise ValueError('Standings incomplete: '+conf)
        y=top
        d.rounded_rectangle((int(x0),y,int(x1),y+section_h),radius=7,fill=c['panel'])
        d.text((x0+12,y+section_h/2),conf.upper()+' CONFERENCE',font=fit(d,conf.upper()+' CONFERENCE',pane_w-24,min(24,int(section_h*.54)),True),fill=WHITE,anchor='lm')
        y+=section_h
        d.rectangle((int(x0),y,int(x1),y+head_h),fill=c['alternate'])
        centers=[];cursor=x0
        for name,v in cols:
            span=pane_w*v/total;centers.append((cursor+span/2,span));cursor+=span
        for (name,_),(cx,span) in zip(cols,centers):
            d.text((cx,y+head_h/2),name,font=fit(d,name,span-2,min(13,int(head_h*.48)),True),fill=PALE,anchor='mm')
        y+=head_h
        for i,t in enumerate(members):
            selected=label(t.get('teamAbbrev'))==team
            d.rectangle((int(x0),y,int(x1),y+row_h),fill=c['panel'] if selected else (c['base'] if i%2==0 else c['alternate']))
            d.line((int(x0),y+row_h,int(x1),y+row_h),fill=(60,80,106),width=1)
            gp=int(t.get('gamesPlayed') or 0);wins=int(t.get('wins') or 0);wr=wins/gp if gp else None
            diff=int(t.get('goalDifferential') or 0);sc=t.get('streakCount') or 0;code=str(t.get('streakCode') or '').upper()
            streak=('OT' if code in ('OT','O') else code)+str(sc) if code else '—'
            name=label(t.get('teamName')) or label(t.get('teamAbbrev'))
            vals=[str(i+1),name,str(gp),str(wins),str(t.get('losses',0)),str(t.get('otLosses',0)),str(t.get('points',0)),f'{wr:.3f}' if wr is not None else '—',str(t.get('goalFor',0)),str(t.get('goalAgainst',0)),f'{diff:+d}' if diff else '0',f"{t.get('l10Wins',0)}-{t.get('l10Losses',0)}-{t.get('l10OtLosses',0)}",streak]
            for j,(value,(cx,span)) in enumerate(zip(vals,centers)):
                color=WHITE
                if j==7 and wr is not None:color=GREEN if wr>.5 else RED if wr<.5 else WHITE
                if j==10:color=GREEN if diff>0 else RED if diff<0 else WHITE
                if j==12:color=GREEN if streak.startswith('W') else RED if streak.startswith('L') else ORANGE if streak.startswith('OT') else WHITE
                f=fit(d,value,span-3,min(17,int(row_h*.52)),selected)
                d.text((cx if j!=1 else cx-span/2+3,y+row_h/2),value,font=f,fill=color,anchor='mm' if j!=1 else 'lm')
            y+=row_h
    foot='UPDATED DAILY - NHL OFFICIAL STANDINGS DATA'
    d.text((w/2,bottom-footer_h+5),foot,font=fit(d,foot,right-left-15,max(12,int(h*.018)),True),fill=PALE,anchor='mt')
    stamp='LAST UPDATED: '+now.strftime('%b %d, %Y - %I:%M %p %Z')
    d.text((w/2,bottom-footer_h+max(23,int(h*.029))),stamp,font=fit(d,stamp,right-left-15,max(12,int(h*.018))),fill=PALE,anchor='mt')
    return finish_texture(im)


def standings_groups(data,team,organization):
    """Return titled groups, ordered by division/conference/league and points."""
    def points(t):
        return (-int(t.get('points') or 0),-int(t.get('wins') or 0),
                -int(t.get('goalDifferential') or 0),label(t.get('teamName')))
    if organization=='League':
        allteams=sorted(data,key=points)
        if len(allteams)!=32:raise ValueError('Standings incomplete: expected 32 NHL teams')
        return [('NHL LEAGUE',allteams)]
    if organization!='Division':raise ValueError('Unknown standings organization')
    bydiv={}
    for t in data:
        division=label(t.get('divisionName'))
        bydiv.setdefault(division,[]).append(t)
    if len(bydiv)!=4 or any(len(v)!=8 for v in bydiv.values()):
        raise ValueError('Standings incomplete: expected four divisions of eight teams')
    for k in bydiv:bydiv[k].sort(key=points)
    chosen=next((t for t in data if label(t.get('teamAbbrev'))==team),None)
    if chosen is None:raise ValueError('Favourite team not found in standings')
    mine=label(chosen.get('divisionName'))
    conf=label(chosen.get('conferenceName'))
    same=[k for k,v in bydiv.items() if k!=mine and label(v[0].get('conferenceName'))==conf]
    others=[k for k,v in bydiv.items() if label(v[0].get('conferenceName'))!=conf]
    if len(same)!=1 or len(others)!=2:raise ValueError('Division/conference mapping invalid')
    others.sort(key=lambda k:points(bydiv[k][0]))
    return [(k.upper()+' DIVISION',bydiv[k]) for k in [mine,same[0],*others]]


def custom_standings(data,size,team,now,organization,im,d,c,left,right,top,bottom):
    w,h=size;portrait=h>w
    groups=standings_groups(data,team,organization)
    # Match the Conference layout's table and footer boundaries exactly.
    # On landscape monitors the Conference footer begins at bottom-footer_h.
    # Leave an extra clearance above it so custom tables never enter the
    # taskbar/footer region, even with fractional row heights.
    conference_footer_h = max(44, int(h*.07))
    if portrait:
        # Match Conference's exact table end and footer positions.
        scale=min(w/1080,h/1920)
        conf_gap=int(12*scale)
        conf_section=int(38*scale)
        conf_head=int(28*scale)
        conf_footer=int(65*scale)
        conf_row=(bottom-top-2*(conf_section+conf_head+conf_gap)-conf_footer)//32
        table_bottom=top+2*(conf_section+conf_head)+conf_gap+32*conf_row
        footer_first_y=table_bottom+conf_gap+int(8*scale)
        footer_second_y=table_bottom+conf_gap+int(33*scale)
    else:
        table_bottom=bottom-conference_footer_h-max(8,int(h*.012))
    if organization=='League':
        if portrait: panes=[(left,right,top,table_bottom,groups[0][0],groups[0][1],1)]
        else:
            gap=int(w*.016);pw=(right-left-gap)/2
            panes=[(left,left+pw,top,table_bottom,'LEAGUE - 1–16',groups[0][1][:16],1),
                   (left+pw+gap,right,top,table_bottom,'LEAGUE - 17–32',groups[0][1][16:],17)]
    elif portrait:
        gap=max(5,int(h*.007));footer=max(55,int(h*.047));ph=(table_bottom-top-3*gap)/4
        panes=[(left,right,top+i*(ph+gap),top+i*(ph+gap)+ph,title,members,1) for i,(title,members) in enumerate(groups)]
    else:
        gap=max(9,int(w*.016));footer=max(52,int(h*.07));pw=(right-left-gap)/2;ph=(table_bottom-top-gap)/2
        # top-left favourite, bottom-left same conference, top-right other leader, bottom-right last
        locations=[(left,top),(left,top+ph+gap),(left+pw+gap,top),(left+pw+gap,top+ph+gap)]
        panes=[(x,x+pw,y,y+ph,title,members,1) for (x,y),(title,members) in zip(locations,groups)]
    cols=[('R',.035),('TEAM',.205),('GP',.052),('W',.044),('L',.044),('OT',.050),('PTS',.055),('WIN%',.079),('GF',.050),('GA',.050),('DIFF',.070),('L10',.104),('STRK',.080)]
    total=sum(v for _,v in cols)
    for x0,x1,y0,y1,title,members,rank_start in panes:
        pw=x1-x0;ph=y1-y0
        section=max(22,min(39,int(ph*.115)));head=max(17,min(29,int(ph*.085)))
        rh=(ph-section-head)/len(members)
        if rh<11:raise ValueError('Monitor too small for standings layout')
        d.rounded_rectangle((int(x0),int(y0),int(x1),int(y0+section)),radius=6,fill=c['panel'])
        d.text((x0+9,y0+section/2),title,font=fit(d,title,pw-18,min(24,int(section*.58)) if portrait else min(23,int(section*.57)),True),fill=WHITE,anchor='lm')
        y=y0+section
        d.rectangle((int(x0),int(y),int(x1),int(y+head)),fill=c['alternate'])
        centers=[];cur=x0
        for name,v in cols:
            span=pw*v/total;centers.append((cur+span/2,span));cur+=span
        for (name,_),(cx,span) in zip(cols,centers):
            d.text((cx,y+head/2),name,font=fit(d,name,span-2,min(16,int(head*.55)) if portrait else min(14,int(head*.53)),True),fill=PALE,anchor='mm')
        y+=head
        for i,t in enumerate(members):
            selected=label(t.get('teamAbbrev'))==team
            d.rectangle((int(x0),int(y),int(x1),int(y+rh)),fill=c['panel'] if selected else c['base'] if i%2==0 else c['alternate'])
            d.line((int(x0),int(y+rh),int(x1),int(y+rh)),fill=(60,80,106),width=1)
            gp=int(t.get('gamesPlayed') or 0);wins=int(t.get('wins') or 0);wr=wins/gp if gp else None
            diff=int(t.get('goalDifferential') or 0);sc=t.get('streakCount') or 0;code=str(t.get('streakCode') or '').upper()
            streak=('OT' if code in ('OT','O') else code)+str(sc) if code else '—'
            vals=[str(rank_start+i),label(t.get('teamName')) or label(t.get('teamAbbrev')),str(gp),str(wins),str(t.get('losses',0)),str(t.get('otLosses',0)),str(t.get('points',0)),f'{wr:.3f}' if wr is not None else '—',str(t.get('goalFor',0)),str(t.get('goalAgainst',0)),f'{diff:+d}' if diff else '0',f"{t.get('l10Wins',0)}-{t.get('l10Losses',0)}-{t.get('l10OtLosses',0)}",streak]
            for j,(v,(cx,span)) in enumerate(zip(vals,centers)):
                color=WHITE
                if j==7 and wr is not None:color=GREEN if wr>.5 else RED if wr<.5 else WHITE
                if j==10:color=GREEN if diff>0 else RED if diff<0 else WHITE
                if j==12:color=GREEN if streak.startswith('W') else RED if streak.startswith('L') else ORANGE if streak.startswith('OT') else WHITE
                f=fit(d,v,span-3,min(17,int(rh*.47)) if portrait else min(21,int(rh*.56)),selected)
                d.text((cx if j!=1 else cx-span/2+3,y+rh/2),v,font=f,fill=color,anchor='mm' if j!=1 else 'lm')
            y+=rh
    foot='UPDATED DAILY - NHL OFFICIAL STANDINGS DATA'
    if portrait:
        fy=footer_first_y
        second_y=footer_second_y
    else:
        # Identical positioning and typography to horizontal_standings.
        fy=bottom-conference_footer_h+5
        second_y=bottom-conference_footer_h+max(23,int(h*.029))
    if portrait:
        foot_font=fit(d,foot,right-left-20,max(12,int(18*scale)),True)
    else:
        foot_font=fit(d,foot,right-left-15,max(12,int(h*.018)),True)
    d.text((w/2,fy),foot,font=foot_font,fill=PALE,anchor='mt')
    stamp='LAST UPDATED: '+now.strftime('%b %d, %Y - %I:%M %p %Z')
    if portrait:
        stamp_font=fit(d,stamp,right-left-20,max(12,int(19*scale)))
    else:
        stamp_font=fit(d,stamp,right-left-15,max(12,int(h*.018)))
    d.text((w/2,second_y),stamp,font=stamp_font,fill=PALE,anchor='mt')
    return finish_texture(im)

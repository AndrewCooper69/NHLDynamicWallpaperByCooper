"""Windows installer GUI; packaged into one EXE with PyInstaller (see build_windows.bat)."""
import json,os,shutil,sys,subprocess,tkinter as tk
from pathlib import Path
from tkinter import ttk,messagebox,filedialog
from teams import TEAMS,CITIES
APP='NHLDynamicWallpaperByCooper'
DATA=Path(os.environ.get('LOCALAPPDATA',Path.home()))/APP
DEFAULT=Path('C:/Applications')/APP
def resource(filename):return Path(getattr(sys,'_MEIPASS',Path(__file__).parent))/filename

def find_legacy():
    # Locate legacy config only when adjacent to installer, common user application folders, or known names.
    roots=[Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).parent,Path.home()/'Applications',Path('C:/Applications/Vibe Coding')]
    results=[]
    for root in roots:
        if not root.exists():continue
        for pattern in ('**/LeafsWallpaper/monitor_config.json','**/NHLStandingsWallpaper/monitor_config.json'):
            # Avoid unbounded recursive scan: restrict to a small set of candidate parents.
            for parent in [root]+[p for p in root.iterdir() if p.is_dir()][:50]:
                f=parent/('LeafsWallpaper/monitor_config.json' if 'LeafsWallpaper/' in pattern and 'NHLStandings' not in pattern else 'NHLStandingsWallpaper/monitor_config.json')
                if f.is_file():results.append(f)
    return list(dict.fromkeys(results))

def install_files(dest,cfg):
    dest.mkdir(parents=True,exist_ok=True);DATA.mkdir(parents=True,exist_ok=True)
    # The packaged app binary is a separate EXE, embedded as an asset in the installer.
    for name in ('WallpaperEngine.exe','Uninstall_NHLDynamicWallpaperByCooper.exe'):
        src=resource(name)
        if not src.exists():raise FileNotFoundError(f'Installer missing bundled file: {name}')
        tmp=dest/(name+'.new');shutil.copy2(src,tmp);os.replace(tmp,dest/name)
    # Save the setup executable as the user-facing configuration app.
    if getattr(sys,'frozen',False):
        source_setup=Path(sys.executable)
        target_setup=dest/'NHL Wallpaper Setup and Change Settings.exe'
        if source_setup.resolve()!=target_setup.resolve():
            temp_setup=dest/'NHL Wallpaper Setup and Change Settings.exe.new'
            shutil.copy2(source_setup,temp_setup)
            os.replace(temp_setup,target_setup)
    config=DATA/'config.json';config.write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    (DATA/'install.json').write_text(json.dumps({'directory':str(dest)}),encoding='utf-8')
    import schedule
    warning = None
    try:
        warning = schedule.install(dest/'WallpaperEngine.exe')
    except Exception as e:
        warning = 'Automatic updates could not be scheduled: '+str(e)
    warning_path=DATA/'scheduler_warning.txt'
    if warning:
        warning_path.write_text(warning,encoding='utf-8')
    elif warning_path.exists():
        warning_path.unlink()
    # Remove obsolete engine name after the replacement has been installed.
    for old_name in ('NHLDynamicWallpaperByCooper.exe', 'NHLDynamicWallpaperByCooper_Setup.exe'):
        obsolete=dest/old_name
        if obsolete.exists():
            try: obsolete.unlink()
            except OSError: pass  # Do not abort an upgrade if an old executable is open.
    # Existing legacy installs remain untouched; user can remove them after verifying the new app.
    subprocess.Popen([str(dest/'WallpaperEngine.exe'),'--update'],cwd=str(dest),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))

class Wizard:
    def __init__(self):
        from monitor_wallpaper import monitors
        self.root=tk.Tk();self.root.title(APP+' Setup');self.root.geometry('660x720');self.root.resizable(False,False)
        self.f=ttk.Frame(self.root,padding=24);self.f.pack(fill='both',expand=True)
        self.folder=tk.StringVar(value=str(DEFAULT));self.team=tk.StringVar(value='Toronto Maple Leafs');self.city=tk.StringVar(value='Toronto');self.organization=tk.StringVar(value='Conference')
        try:
            self.ms=monitors();self.monitor_error=None
        except Exception as e:
            self.ms=[];self.monitor_error=str(e)
        self.monitor_names={'Disabled':None}
        for m in self.ms:self.monitor_names[f"{m['index']}: {m['width']} x {m['height']} - position {m['position']}"]=m['id']
        self.calendar=tk.StringVar(value='Disabled');self.standings=tk.StringVar(value='Disabled')
        if self.ms:
            wide=next((m for m in self.ms if m['width']>=m['height']),self.ms[0]);tall=next((m for m in self.ms if m['height']>m['width'] and m['id']!=wide['id']),None)
            self.calendar.set(next(k for k,v in self.monitor_names.items() if v==wide['id']))
            if tall:self.standings.set(next(k for k,v in self.monitor_names.items() if v==tall['id']))
        self.legacy=find_legacy();cfg=DATA/'config.json'
        if cfg.exists():
            try:
                old=json.loads(cfg.read_text(encoding='utf-8'))
                self.team.set(next(t[1] for t in TEAMS if t[0]==old['team']));self.city.set(old['city']);self.organization.set(old.get('standings_organization','Conference'))
                for var,key in ((self.calendar,'calendar'),(self.standings,'standings')):
                    var.set(next((n for n,mid in self.monitor_names.items() if mid==old.get('monitors',{}).get(key)),'Disabled'))
                installed=DATA/'install.json'
                if installed.exists():
                    candidate=Path(json.loads(installed.read_text(encoding='utf-8'))['directory'])
                    if candidate.name.lower()==APP.lower() and (candidate/('WallpaperEngine.exe')).is_file():
                        self.folder.set(str(candidate))
            except Exception:pass
        elif self.legacy:
            for f in self.legacy:
                try:mid=json.loads(f.read_text(encoding='utf-8'))['monitor_id']
                except Exception:continue
                name=next((k for k,v in self.monitor_names.items() if v==mid),None)
                if name:
                    (self.standings if 'NHLStandings' in str(f) else self.calendar).set(name)
        ttk.Label(self.f,text=APP, font=('Segoe UI',17,'bold')).pack(anchor='w')
        ttk.Label(self.f,text='Install or upgrade the NHL calendar and standings wallpapers.').pack(anchor='w',pady=(0,15))
        self.entry('Installation folder',self.folder,folder=True)
        self.combo('Favourite NHL team',self.team,[t[1] for t in TEAMS])
        self.combo('Viewing city (broadcast market)',self.city,CITIES)
        self.combo('Calendar display',self.calendar,list(self.monitor_names))
        self.combo('Standings display',self.standings,list(self.monitor_names))
        self.combo('Standings organization',self.organization,['Division','Conference','League'])
        note='Existing installation detected: settings will be preserved.' if cfg.exists() else (f'{len(self.legacy)} previous monitor configurations detected; monitor choices prefilled.' if self.legacy else 'No previous configuration found.')
        ttk.Label(self.f,text=note,wraplength=600).pack(anchor='w',pady=12)
        if self.monitor_error:
            ttk.Label(self.f,text='Monitor detection failed: '+self.monitor_error+'\nPlease do not install yet. The monitor component needs to be repaired.',wraplength=600,foreground='red').pack(anchor='w')
        ttk.Label(self.f,text='Older standalone apps are only removed when explicitly selected in the uninstaller.',wraplength=600).pack(anchor='w')
        self.install_button=ttk.Button(self.f,text='Install / Save Settings',command=self.submit)
        self.install_button.pack(anchor='e',pady=20)
        if self.monitor_error:self.install_button.configure(state='disabled')
    def entry(self,label,var,folder=False):
        ttk.Label(self.f,text=label).pack(anchor='w',pady=(8,2));row=ttk.Frame(self.f);row.pack(fill='x');ttk.Entry(row,textvariable=var,width=67).pack(side='left',fill='x',expand=True)
        if folder:ttk.Button(row,text='Browse',command=lambda:var.set(filedialog.askdirectory(initialdir=var.get()) or var.get())).pack(side='left',padx=5)
    def combo(self,label,var,values):
        ttk.Label(self.f,text=label).pack(anchor='w',pady=(8,2));ttk.Combobox(self.f,textvariable=var,values=values,state='readonly',width=76).pack(fill='x')
    def submit(self):
        a=self.monitor_names[self.calendar.get()];b=self.monitor_names[self.standings.get()]
        if not a and not b:messagebox.showerror('Selection needed','Assign at least one monitor.');return
        if a and a==b:messagebox.showerror('Monitor conflict','Each wallpaper needs a different monitor.');return
        cfg={'team':next(t[0] for t in TEAMS if t[1]==self.team.get()),'city':self.city.get(),'monitors':{'calendar':a,'standings':b},'standings_organization':self.organization.get()}
        if self.monitor_error:
            messagebox.showerror('Monitor detection failed',self.monitor_error);return
        destination=Path(self.folder.get()).resolve()
        if destination.name.lower()!=APP.lower():
            messagebox.showerror('Unsafe installation folder','Select a dedicated folder named '+APP+' so older wallpaper applications cannot be overwritten.');return
        try:install_files(Path(self.folder.get()),cfg)
        except Exception as e:messagebox.showerror('Installation failed',str(e));return
        warning_file=DATA/'scheduler_warning.txt'
        if warning_file.exists():
            messagebox.showwarning('Installed - scheduler warning','Application installed, but automatic updates need attention:\n'+warning_file.read_text(encoding='utf-8'))
        else:
            messagebox.showinfo('Installed','Installed successfully. Wallpaper update started. Run NHL Wallpaper Setup and Change Settings.exe again to change settings.')
        self.root.destroy()
if __name__=='__main__':Wizard().root.mainloop()

"""Safely uninstall the unified app and its own scheduled tasks."""
import json
import os
import subprocess
import sys
import tempfile
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

APP = 'NHLDynamicWallpaperByCooper'
DATA = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / APP
TASKS = ('NHLDynamicWallpaperByCooper_Daily', 'NHLDynamicWallpaperByCooper_Logon')
MARKERS = ('WallpaperEngine.exe', 'NHL Wallpaper Setup and Change Settings.exe', 'NHLDynamicWallpaperByCooper_Setup.exe', 'Uninstall_NHLDynamicWallpaperByCooper.exe')


def installed_folder():
    record = DATA / 'install.json'
    if record.is_file():
        try:
            return Path(json.loads(record.read_text(encoding='utf-8'))['directory']).resolve()
        except (ValueError, KeyError, OSError, TypeError):
            pass
    return Path(sys.executable).resolve().parent


def safe_folder(folder):
    # Never delete a parent folder, an arbitrary selected folder, or an old standalone app.
    return (folder.name.casefold() == APP.casefold()
            and folder.is_dir()
            and any((folder / marker).is_file() for marker in MARKERS))


# This script runs in a separate PowerShell process, *after* the uninstaller exits.
# The directory and PID are passed as separate arguments, not interpolated into code.
CLEANUP_PS1 = r'''param(
    [Parameter(Mandatory=$true)][string]$InstallDir,
    [Parameter(Mandatory=$true)][string]$DataDir,
    [Parameter(Mandatory=$true)][int]$UninstallerPid,
    [Parameter(Mandatory=$true)][string]$LogPath
)
$ErrorActionPreference = 'Stop'
try {
    # Wait until Windows releases the executable before removing its directory.
    for ($i=0; $i -lt 60; $i++) {
        if (-not (Get-Process -Id $UninstallerPid -ErrorAction SilentlyContinue)) { break }
        Start-Sleep -Seconds 1
    }
    if ((Split-Path -Leaf $InstallDir) -ine 'NHLDynamicWallpaperByCooper') {
        throw 'Refusing to delete a directory with an unexpected name.'
    }
    $markers = @('WallpaperEngine.exe', 'NHL Wallpaper Setup and Change Settings.exe', 'NHLDynamicWallpaperByCooper_Setup.exe', 'Uninstall_NHLDynamicWallpaperByCooper.exe')
    $found = $false
    foreach ($marker in $markers) { if (Test-Path -LiteralPath (Join-Path $InstallDir $marker)) { $found=$true; break } }
    if (-not $found) { throw 'Application marker missing. Refusing to delete.' }
    $deleted = $false
    for ($i=0; $i -lt 15; $i++) {
        try {
            Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction Stop
            $deleted = -not (Test-Path -LiteralPath $InstallDir)
            if ($deleted) { break }
        } catch { Start-Sleep -Seconds 2 }
    }
    if (-not $deleted) { throw 'Application directory could not be deleted. Check for running processes or locked files.' }
    if (Test-Path -LiteralPath $DataDir) { Remove-Item -LiteralPath $DataDir -Recurse -Force -ErrorAction Stop }
    'Uninstall completed successfully.' | Set-Content -LiteralPath $LogPath -Encoding UTF8
} catch {
    ('Uninstall incomplete: ' + $_.Exception.Message) | Set-Content -LiteralPath $LogPath -Encoding UTF8
}
'''


def main():
    root = tk.Tk()
    root.withdraw()
    folder = installed_folder()
    if not safe_folder(folder):
        messagebox.showerror('Unsafe uninstall location',
            'The installed application folder could not be verified. No files or tasks were removed.\n\n'
            f'Folder: {folder}')
        root.destroy()
        return
    if not messagebox.askyesno('Uninstall ' + APP,
            'Remove NHLDynamicWallpaperByCooper, its generated wallpapers, settings, and scheduled tasks?\n\n'
            f'Installation folder:\n{folder}\n\n'
            'The two older standalone wallpaper applications will not be touched.'):
        root.destroy()
        return
    # Create helper BEFORE modifying anything. No shell command parsing or cmd/start quoting.
    helper = Path(tempfile.gettempdir()) / f'nhl_cooper_cleanup_{os.getpid()}.ps1'
    log = Path(tempfile.gettempdir()) / 'nhl_cooper_uninstall_result.txt'
    try:
        helper.write_text(CLEANUP_PS1, encoding='utf-8-sig')
        subprocess.Popen([
            'powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
            '-File', str(helper), '-InstallDir', str(folder), '-DataDir', str(DATA),
            '-UninstallerPid', str(os.getpid()), '-LogPath', str(log)
        ], creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), close_fds=True)
    except OSError as exc:
        messagebox.showerror('Uninstall could not start', str(exc))
        root.destroy()
        return
    # Scheduled tasks are removed only after the cleanup process starts successfully.
    for task in TASKS:
        subprocess.run(['schtasks', '/Delete', '/F', '/TN', task],
                       capture_output=True, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    messagebox.showinfo('Uninstall started',
        'The cleanup process has started. The application folder should disappear after this window closes.\n\n'
        f'If files remain, check the result log:\n{log}')
    root.destroy()


if __name__ == '__main__':
    main()
